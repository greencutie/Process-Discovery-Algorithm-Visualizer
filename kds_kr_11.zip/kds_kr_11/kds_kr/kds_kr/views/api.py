from django.contrib import messages
from django.http import HttpResponse, HttpResponseNotFound
from django.shortcuts import render, redirect
from kds_kr.backend import alpha_miner
from kds_kr.backend import fuzzy_miner
from kds_kr.backend import inductive_miner
import json
import traceback

import re

from pm4py.algo.discovery.alpha import algorithm as alpha_miner_algo
from pm4py.algo.discovery.inductive import algorithm as inductive_miner_algo
from pm4py.visualization.process_tree import visualizer as pt_visualizer
import pandas as pd
from pm4py.objects.log.util import dataframe_utils
from pm4py.objects.conversion.log import converter as log_converter
from pm4py.visualization.petri_net import visualizer as pn_visualizer
from django.forms.utils import flatatt
from django.utils.safestring import mark_safe

def link_check_funk(request):
    data = ['''s1,10
s2,15
s3,20
s4,25''',
        '''s1,10
s3,15
s2,16
s4,20''',
        '''s5,1
s6,4''']
    
    log, _ = alpha_miner.get_log_data(data)

    parameters = {log_converter.Variants.TO_EVENT_LOG.value.Parameters.CASE_ID_KEY: 'case'}
    event_log = log_converter.apply(log, parameters=parameters, variant=log_converter.Variants.TO_EVENT_LOG)
    net, initial_marking, final_marking = alpha_miner_algo.apply(event_log)

    parameters = {pn_visualizer.Variants.WO_DECORATION.value.Parameters.FORMAT: "svg"}
    gviz = pn_visualizer.apply(net, initial_marking, final_marking, parameters=parameters)
    pn_visualizer.save(gviz, "alpha.svg")

    # with open("alpha.svg", "rb") as image_file:
 #        image_data = base64.b64encode(image_file.read()).decode('utf-8')

    with open('alpha.svg', 'r') as fd:
        content = fd.read()

    image_data = mark_safe(re.sub(r'(<svg[^>]*)', r'\1{}',
                            content, flags=re.MULTILINE))

    am = alpha_miner.alpha_miner(data)
    # print(*am.get_history(), sep='\n')
    # print(image_data)
    # print(mark_safe(am.get_history()))
    return {'schema': am.get_scheme(), 'history': json.dumps(am.get_history()), 'items': am.items, 'pseudocode': alpha_miner.PSEUDOCODE,
    'image': mark_safe(am.new_scheme_img)}


def main_page(request):
    if request.method == 'GET':
        return render(request, "index.html")
    return HttpResponseNotFound()

def filter_destinct(data):
    for j in data['history']:
        for n in [2,3]:
            # print('[REMOVE DUPLICATES]')
            # print(j[n])
            j[n] = alpha_miner.remove_duplicates(j[n])
            # print(j[n])
    data['history'] = json.dumps(data['history'])
    # print(data)
    return data

def link_miner(request):
    if request.method == 'POST':
        print(request.POST)
        print(request.POST.get('in_data'))
        print(request.POST.get('type'))
        try:
            if request.POST.get('type') == '0':
                print('ALPHA')
                return render(request, "miner.html", link_alpha_miner(request))
            elif request.POST.get('type') == '1':
                print('FUZZY')
                return render(request, "miner.html", link_fuzzy_miner(request))
            elif request.POST.get('type') == '2':
                print('3-rd')
                return render(request, "miner.html", link_inductive_miner(request))
        except Exception as e:
            messages.add_message(request, messages.WARNING, 'Wrong data format.')
            print(e)
            traceback.print_exc()
            return redirect(main_page)
        return redirect(main_page)
        

    return render(request, "miner.html", link_check_funk(request))

    return HttpResponseNotFound()


def link_alpha_miner(request):
    if request.method == 'POST':
        try:
            in_data = request.POST.get('in_data')
            in_data = re.sub('\r', '', in_data)
            print('DATA:')
            print('|',in_data,'|')
            data = in_data.split('\n\n')
            print('|',data,'|')
            am = alpha_miner.alpha_miner(data)
        except Exception as e:
            print(e)
            raise
        return filter_destinct({'schema': am.get_scheme(), 'history': am.get_history(), 'items': am.items, 'pseudocode': alpha_miner.PSEUDOCODE})
    return HttpResponseNotFound()


def link_fuzzy_miner(request):
    if request.method == 'POST':
        try:
            in_data = request.POST.get('in_data')
            in_data = re.sub('\r', '', in_data)
            print('DATA:')
            print('|',in_data,'|')
            data = in_data.split('\n\n')
            print('|',data,'|')
            fm = fuzzy_miner.fuzzy_miner(data, int(request.POST.get('percent')))
        except Exception as e:
            print(e)
            raise
        pseudo_code = fuzzy_miner.PSEUDOCODE
        for i in pseudo_code:
            for j in i:
                i[j] = re.sub("K", str(fm.grad_proc), i[j])
        return filter_destinct({'schema': fm.get_scheme(), 'history': fm.get_history(), 'items': fm.items, 'pseudocode': pseudo_code})
    return HttpResponseNotFound()


def link_inductive_miner(request):
    if request.method == 'POST':
        try:
            in_data = request.POST.get('in_data')
            in_data = re.sub('\r', '', in_data)
            print('DATA:')
            print('|',in_data,'|')
            data = in_data.split('\n\n')
            print('|',data,'|')
            im = inductive_miner.inductive_miner(data)
        except Exception as e:
            print(e)
            raise
        return filter_destinct({'schema': im.get_scheme(), 'history': im.get_history(), 'items': im.items, 'pseudocode': inductive_miner.PSEUDOCODE})
    return HttpResponseNotFound()

"""

aba, 1
bac, 2
aba, 4

"""