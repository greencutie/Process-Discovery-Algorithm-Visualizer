function test_plot(){var g=new Dracula.Graph();g.addEdge("strawberry","cherry");g.addEdge("strawberry","apple");g.addEdge("strawberry","tomato");g.addEdge("tomato","apple");g.addEdge("tomato","kiwi");g.addEdge("cherry","apple");g.addEdge("cherry","kiwi",{directed:true});var layouter=new Dracula.Layout.Spring(g);layouter.layout();var renderer=new Dracula.Renderer.Raphael('#plot',g,400,300);renderer.draw();}
function plot_by_pairs(){var data=JSON().parse(document.getElementById('data').textContent)
console.log(data)
var g=new Dracula.Graph();g.addEdge("Start","cherry");};