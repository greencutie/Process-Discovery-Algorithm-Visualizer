var current_step=-1;var len=100;function hasClass(el,className)
{if(el.classList)
return el.classList.contains(className);return!!el.className.match(new RegExp('(\\s|^)'+className+'(\\s|$)'));}
function addClass(el,className)
{if(el.classList)
el.classList.add(className)
else if(!hasClass(el,className))
el.className+=" "+className;}
function removeClass(el,className)
{if(el.classList)
el.classList.remove(className)
else if(hasClass(el,className))
{var reg=new RegExp('(\\s|^)'+className+'(\\s|$)');el.className=el.className.replace(reg,' ');}}
function parse_links(n,data){var dir_links=data[n][2]
var parallel_links=data[n][3]
var select_ind=data[n][5]
var elems=document.getElementsByClassName('source_row')
var s=`
					<tr style="position: sticky; top: 0;">
                        <th width="45%">First</th>
                        <th width="10%">link</th>
                        <th width="45%">Second</th>
                    </tr>`
for(var i=0;i<dir_links.length;i++){var cls=''
if(i==n||i==select_ind){cls='selected'}
s+=`
					<tr class="directed_row ${cls}">
                        <td>${dir_links[i][0]}</td>
                        <td style="text-align: center;">-></td>
                        <td>${dir_links[i][1]}</td>
                    </tr>
		`}
for(var i=0;i<parallel_links.length;i++){var cls=''
if(i==n-elems.length||i==select_ind-elems.length){cls='selected'}
s+=`
					<tr class="parralel_row ${cls}">
                        <td>${parallel_links[i][0]}</td>
                        <td style="text-align: center;">||</td>
                        <td>${parallel_links[i][1]}</td>
                    </tr>
		`}
document.getElementById('link_table').innerHTML=s}
function test_plot(){var g=new Dracula.Graph();g.addEdge("strawberry","cherry");g.addEdge("strawberry","apple");g.addEdge("strawberry","tomato");g.addEdge("tomato","apple");g.addEdge("tomato","kiwi");g.addEdge("cherry","apple");g.addEdge("cherry","kiwi",{directed:true});var layouter=new Dracula.Layout.Spring(g);layouter.layout();var box=document.getElementById('plot')
var renderer=new Dracula.Renderer.Raphael('#plot',g,box.offsetWidth,box.offsetHeight);renderer.draw();}
function plot_by_pairs(idx){var data=JSON.parse(document.getElementById('data').textContent.replace(/\'/g,"\""))
len=data.length
parse_links(idx,data)
var g=new Dracula.Graph();for(const[first,value]of Object.entries(data[idx][4])){for(const[second,val]of Object.entries(value)){var value_label=val
if(value_label==1){value_label=''}
g.addEdge(first,second,{directed:true,label:value_label});}}
var layouter=new Dracula.Layout.Spring(g);layouter.layout();document.getElementById('plot').textContent=""
var box=document.getElementById('plot')
var renderer=new Dracula.Renderer.Raphael('#plot',g,box.offsetWidth,box.offsetHeight);renderer.draw();}
function next_step(){var json_data=JSON.parse(document.getElementById('data').textContent.replace(/\'/g,"\""))
if(current_step<json_data.length-1){var elems=document.getElementsByClassName('source_row')
if(elems.length>current_step&&current_step>=0){removeClass(elems[current_step],'selected')}
if(json_data[current_step][6]&&json_data[current_step][6]>=0)
removeClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
current_step=current_step+1;if(json_data[current_step][6]&&json_data[current_step][6]>=0)
addClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
plot_by_pairs(current_step)
if(elems.length>current_step){addClass(elems[current_step],'selected')}
document.getElementById('bar').style.width=(current_step+1)*100/len+"%";}}
function previous_step(){var json_data=JSON.parse(document.getElementById('data').textContent.replace(/\'/g,"\""))
if(current_step>0){var elems=document.getElementsByClassName('source_row')
if(elems.length>current_step){removeClass(elems[current_step],'selected')}
if(json_data[current_step][6]&&json_data[current_step][6]>=0)
removeClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
current_step=current_step-1;if(json_data[current_step][6]&&json_data[current_step][6]>=0)
addClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
plot_by_pairs(current_step)
if(elems.length>current_step){addClass(elems[current_step],'selected')}
document.getElementById('bar').style.width=(current_step+1)*100/len+"%";}}