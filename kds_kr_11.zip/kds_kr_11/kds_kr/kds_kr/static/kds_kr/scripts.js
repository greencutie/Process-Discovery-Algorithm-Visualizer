function preset1(){
	document.getElementById('in_data').value = `Tel_call, 1
Document_writing, 10
Doc_sending, 20

Message receiving, 50
Document_sending, 55

Message receiving, 50
Document_sending, 45`
}

function preset2(){
	document.getElementById('in_data').value = `Tel_call, 1
Document_writing, 10
Doc_sending, 20

Message receiving, 50
Document_sending, 45

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55`
}

function preset3(){
	document.getElementById('in_data').value = `Event 1,10
Event 2,15
Event 3,20
Event 4,25

Event 1,10
Event 3,15
Event 2,16
Event 4,20

Event 5,1
Event 6,4`
}





function changedSelected(){
	item = document.getElementById('select_type')
	if (item.value == 1){
		document.getElementById('percent_input').style.display = 'block'
	}
	else{
		document.getElementById('percent_input').style.display = 'none'
	}
}