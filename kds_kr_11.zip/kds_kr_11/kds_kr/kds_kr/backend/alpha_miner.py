import copy
import pandas as pd
from pm4py.objects.log.util import dataframe_utils

from pm4py.algo.discovery.alpha import algorithm as alpha_miner_algo
from pm4py.algo.discovery.inductive import algorithm as inductive_miner_algo
from pm4py.visualization.process_tree import visualizer as pt_visualizer
import pandas as pd
from pm4py.objects.log.util import dataframe_utils
from pm4py.objects.conversion.log import converter as log_converter
from pm4py.visualization.petri_net import visualizer as pn_visualizer
from django.forms.utils import flatatt
from django.utils.safestring import mark_safe
import re
from pm4py.objects.petri_net.obj import PetriNet, Marking
from pm4py.objects.petri_net.utils import petri_utils
from pm4py.objects.petri_net.exporter import exporter as pnml_exporter
from pm4py.visualization.petri_net import visualizer as pn_visualizer
import tempfile

import pandas as pd
import numpy as np
from graphviz import Digraph
from sklearn.cluster import KMeans
import pm4py
from pm4py.objects.conversion.log import converter as log_converter
from pm4py.algo.discovery.dfg import algorithm as dfg_discovery
from collections import Counter, defaultdict
from pm4py.visualization.petri_net import visualizer as pn_visualizer
from pm4py.objects.log.obj import Event
from pm4py.objects.petri_net.obj import PetriNet, Marking
from pm4py.objects.petri_net.utils import petri_utils
from sklearn.metrics import silhouette_score
from pm4py.objects.petri_net.exporter import exporter as pnml_exporter
from pm4py.objects.log.exporter.xes import exporter as xes_exporter
from pm4py.algo.evaluation.replay_fitness import algorithm as replay_fitness_evaluator
from pm4py.algo.evaluation.precision import algorithm as precision_evaluator
from pm4py.algo.evaluation.generalization import algorithm as generalization_evaluator
from pm4py.algo.evaluation.simplicity import algorithm as simplicity_evaluator
import datetime


def pos_in_arr(arr, item):
    for i in range(len(arr)):
        if arr[i] == item:
            return i


def remove_duplicates(data):
    d = {}
    for i in data:
        d.setdefault(i[0], {})[i[1]] = i
    # print(d)
    res = []
    for k in d:
        for kk in d[k]:
            res.append(d[k][kk])
    return res

def get_log_data(data):
    log_arr = []
    for ind, c in enumerate(data):
        cdata = list(map(lambda x: [x.split(',', 1)[0], (int(x.split(',', 2)[1]) if len(x.split(',', 2))>1 else -1)], c.split('\n')))
        cdata = list(filter(lambda x: x[1] >= 0, cdata))
        cdata.sort(key=lambda x: x[1])
        log_arr += [[ind, i[0], i[1]] for i in cdata]
    log = pd.DataFrame()
    log[['case', 'concept:name', 'timestamp']] = log_arr
    log = dataframe_utils.convert_timestamp_columns_in_df(log, timest_columns='timestamp')

    return log, log_arr





class alpha_miner:

    def gen_img_by_links_list(self):
        links = copy.deepcopy(self.map)
        net = PetriNet("new_petri_net")
        # creating source, p_1 and sink place
        decorations = {}
        places_dict = {}
        places_dict_raw = {}
        places_dict_raw_used = {}
        transitions_dict = {}

        places_dict['_start'] = PetriNet.Place('_start')

        places_dict['_end'] = PetriNet.Place('_end')

        # print(links)

        for i in links:
            if i != '_start':
                transitions_dict.setdefault(i, PetriNet.Transition(str(i), str(i)))

            for j in links[i]:
                if j != '_end':
                    transitions_dict.setdefault(j, PetriNet.Transition(str(j), str(j)))
                # if i != '_start' and j != '_end':
                places_dict.setdefault(f'{i}->{j}', places_dict_raw.setdefault(i, PetriNet.Place(f'{i}')))
                decorations.setdefault(places_dict[f'{i}->{j}'], {"label": 0, "color": 'grey'})['label'] += links[i][j]
                # transitions_dict[f'{i}->{j}'] = PetriNet.Transition(f'{i}->{j}', str(links[i][j]))

        for i in places_dict:
            if i in ['_start', '_end']:
                continue
            decorations[places_dict[i]]['label'] = str(decorations[places_dict[i]]['label'])
        #     decorations[places_dict[i]] = {"label": 0, "color": 'grey'}

        for i in transitions_dict:
            decorations[transitions_dict[i]] = {"label": i, "color": 'aqua'}

        if self.history[-1][0] == 'Try add new first operation':
            transitions_dict[str(self.history[-1][1])] = PetriNet.Transition(str(self.history[-1][1]), str(self.history[-1][1]))
            _item = transitions_dict[str(self.history[-1][1])]
            decorations.setdefault(_item, {"label": str(self.history[-1][1]), 'color': 'yellow'})

        if self.history[-1][0] == 'Try add new last operation':
            transitions_dict[str(self.history[-1][1])] = PetriNet.Transition(str(self.history[-1][1]), str(self.history[-1][1]))
            _item = transitions_dict[str(self.history[-1][1])]
            decorations.setdefault(_item, {"label": str(self.history[-1][1]), 'color': 'yellow'})

        if self.history[-1][0] == 'Add new first operation':
            _item = transitions_dict[str(self.history[-1][1])]
            decorations[_item]['color'] = 'red'
            # places_dict.setdefault(f'_start->{str(self.history[-1][1])}', PetriNet.Place(f'_start->{str(self.history[-1][1])}'))
            decorations[places_dict[f'_start->{str(self.history[-1][1])}']]["color"] = 'red'
        
        if self.history[-1][0] == 'Add new last operation':
            _item = transitions_dict[str(self.history[-1][1])]
            decorations[_item]['color'] = 'red'
            # places_dict.setdefault(f'_start->{str(self.history[-1][1])}', PetriNet.Place(f'_start->{str(self.history[-1][1])}'))
            decorations[places_dict[f'{str(self.history[-1][1])}->_end']]["color"] = 'red'

            # _item = places_dict[str(self.history[-1][1])]
            # _trans = transitions_dict[f'{_item.name}->_end']
            # decorations.setdefault(_item, {"label": _trans.label})
            # decorations[_item]["color"] = 'red'
            # decorations[_trans] = {"label": _item.name, "color": 'red'}
        
        if self.history[-1][0] == 'Add new operation':
            _item1 = transitions_dict[str(self.history[-1][1][0])]
            _item2 = transitions_dict[str(self.history[-1][1][1])]
            _trans = places_dict[f'{_item1.name}->{_item2.name}']
            decorations[_item1]["color"] = 'red'
            decorations[_item2]["color"] = 'red'
            decorations[_trans]["color"] = 'red'

        decorations[places_dict['_start']] = {"label": 'Start', "color": 'green'}
        decorations[places_dict['_end']] = {"label": 'End', "color": 'yellow'}


        for i in places_dict:
            items = i.split('->')
            if i not in ['_start', '_end'] and (items[0] == '_start' or items[1] == '_end'):
                continue
            if not places_dict_raw_used.get(places_dict[i], 0):
                places_dict_raw_used[places_dict[i]] = 1
                net.places.add(places_dict[i])

        for i in transitions_dict:
            net.transitions.add(transitions_dict[i])

        # source = PetriNet.Place("source")
        # sink = PetriNet.Place("sink")
        # p_1 = PetriNet.Place("p_1")
        # # add the places to the Petri Net
        # net.places.add(source)
        # net.places.add(sink)
        # net.places.add(p_1)
        # # Create transitions
        # t_1 = PetriNet.Transition("name_1", "label_1")
        # t_2 = PetriNet.Transition("name_2", "label_2")
        # # Add the transitions to the Petri Net
        # net.transitions.add(t_1)
        # net.transitions.add(t_2)
        # Add arcs
        # from pm4py.objects.petri_net.utils import petri_utils
        places_dict_raw_used = {}
        for i in places_dict:
            if i in ['_start', '_end']:
                continue
            items = i.split('->')
            if items[0] == '_start' and items[1] == '_end':
                if not places_dict_raw_used.get(places_dict[items[1]], 0):  # not places_dict_raw_used.get(places_dict[items[0]], 0) or 
                #     places_dict_raw_used[places_dict[items[0]]] = 1
                    places_dict_raw_used[places_dict[items[1]]] = 1
                petri_utils.add_arc_from_to(places_dict[items[0]], places_dict[items[1]], net)
            if items[0] == '_start':
                # if not places_dict_raw_used.get(places_dict[items[0]], 0):
                #     places_dict_raw_used[places_dict[items[0]]] = 1
                petri_utils.add_arc_from_to(places_dict[items[0]], transitions_dict[items[1]], net)
            elif items[1] == '_end':
                # if not places_dict_raw_used.get(places_dict[items[1]], 0):
                #     places_dict_raw_used[places_dict[items[1]]] = 1
                petri_utils.add_arc_from_to(transitions_dict[items[0]], places_dict[items[1]], net)
            else:
                if not places_dict_raw_used.get(places_dict[i], 0):
                    places_dict_raw_used[places_dict[i]] = 1
                    petri_utils.add_arc_from_to(transitions_dict[items[0]], places_dict[i], net)
                petri_utils.add_arc_from_to(places_dict[i], transitions_dict[items[1]], net)
        # petri_utils.add_arc_from_to(source, t_1, net)
        # petri_utils.add_arc_from_to(t_1, p_1, net)
        # petri_utils.add_arc_from_to(p_1, t_2, net)
        # petri_utils.add_arc_from_to(t_2, sink, net)


        # Adding tokens
        initial_marking = Marking()
        initial_marking[places_dict['_start']] = 'Start'
        final_marking = Marking()
        final_marking[places_dict['_end']] = 'End'
        # decorations[t_1] = {"label": t_1.label, "color": 'blue'}

        gviz = graphviz_visualization(net, initial_marking=initial_marking, final_marking=final_marking,
                                  decorations=decorations, image_format='svg')

        pn_visualizer.save(gviz, "alpha.svg")

        with open('alpha.svg', 'r') as fd:
            content = fd.read()

        image_data = mark_safe(re.sub(r'(<svg[^>]*)', r'\1{}',
                            content, flags=re.MULTILINE))


        return image_data


    def parse_items_to_log(self, pind=None):
        log_arr = []
        ind = 1
        skip_next = 0
        if pind is None or pind <= 0:
            items = self.items
        else:
            items = self.items[:-pind]

        for i in items:
            if skip_next:
                skip_next = 0
                continue
            if len(i['name']) == 0:
                skip_next = 1
                ind += 1
                continue
            log_arr.append([ind, i['name'], i['time']])

        log = pd.DataFrame()
        print(self.items)
        print(log_arr)
        log[['case', 'concept:name', 'timestamp']] = log_arr
        log = dataframe_utils.convert_timestamp_columns_in_df(log, timest_columns='timestamp')

        return log, log_arr

    def gen_csv_img(self, pind=None, algo=alpha_miner_algo):
        log, _ = self.parse_items_to_log(pind)

        parameters = {log_converter.Variants.TO_EVENT_LOG.value.Parameters.CASE_ID_KEY: 'case'}
        event_log = log_converter.apply(log, parameters=parameters, variant=log_converter.Variants.TO_EVENT_LOG)
        net, initial_marking, final_marking = algo.apply(event_log)

        parameters = {pn_visualizer.Variants.WO_DECORATION.value.Parameters.FORMAT: "svg"}

        # gviz = pn_visualizer.apply(net, initial_marking, final_marking, parameters=parameters)
        gviz = graphviz_visualization(net, initial_marking=initial_marking, final_marking=final_marking,
                                  decorations={}, image_format='svg')

        pn_visualizer.save(gviz, "alpha.svg")

        with open('alpha.svg', 'r') as fd:
            content = fd.read()

        image_data = mark_safe(re.sub(r'(<svg[^>]*)', r'\1{}',
                            content, flags=re.MULTILINE))


        return image_data

    def add_only_first(self, item, ind):
        self.history.append(['Try add new first operation', item, self.pcpy, self.dcpy, copy.deepcopy(self.map), ['_start', item], 7])
        self.history[-1].append(self.gen_img_by_links_list())
        isfirst = 1
        for j in self.pairs:
            if item == j[1]:
                isfirst = 0
                break
        if isfirst:
            # print('[FIRST]')
            self.map.setdefault('_start', {})[item]=self.map.setdefault('_start', {}).get(item,0)
            # print(self.map)
            if self.map['_start'][item] == 0:
                self.history.append(['Add new first operation', item, self.pcpy, self.dcpy, copy.deepcopy(self.map), ['_start', item], 8])
                self.history[-1].append(self.gen_img_by_links_list())
                # print(self.map)
                # print(*self.history, '\n\n', sep='\n')
            else:
                self.history = self.history[:-1]
            self.map['_start'][item]+=1
            # print(self.map)
            # print(*self.history, '\n\n', sep='\n')

    def add_only_last(self, item, ind):
        print(item)
        self.history.append(['Try add new last operation', item, self.pcpy, self.dcpy, copy.deepcopy(self.map), [item, '_end'], 12])
        self.history[-1].append(self.gen_img_by_links_list())
        islast = 1
        for j in self.pairs:
            if item == j[0]:
                islast = 0
                break
        if islast:
            self.map.setdefault(item, {})['_end']=self.map.setdefault(item, {}).get('_end',0)
            if self.map[item]['_end'] == 0:
                self.history.append(['Add new last operation', item, self.pcpy, self.dcpy, copy.deepcopy(self.map), [item, '_end'], 13])
                self.history[-1].append(self.gen_img_by_links_list())
            else:
                self.history = self.history[:-1]
            self.map[item]['_end']+=1

    def find_duals(self):
        self.dual_del = {}
        for i in range(len(self.pairs)):
            for j in range(i+1, len(self.pairs)):
                if (self.pairs[i][0] == self.pairs[j][1] and self.pairs[i][1] == self.pairs[j][0]):
                    self.dual.append(self.pairs[i])
                    self.dual_del[i]=1
                    self.dual_del[j]=1
                    self.history.append(['Find parralel operations', self.dual[-1].copy(), 
                        remove_duplicates([self.pairs[i] for i in range(len(self.pairs)) if i not in self.dual_del.keys()]), self.dual.copy(), copy.deepcopy(self.map), 
                        self.dual[-1].copy(), 5])
                        # self.gen_csv_img(len(cdata)-i)])
                    self.history[-1].append(self.gen_img_by_links_list())

                # elif self.pairs[i][0] == self.pairs[j][0] and self.pairs[i][1] == self.pairs[j][1]:
                #     self.dual_del[max(i, j)] = 1
        lddel = list(self.dual_del)
        lddel.sort(reverse=True)
        for i in lddel:
            del self.pairs[i]

    def __init__(self, data, old_algo=False):
        self.history = []
        self.map = {}
        self.pairs = []
        self.items = []
        self.dual = []
        self.dual_del = {}
        for c in data:
            cdata = list(map(lambda x: [x.split(',', 1)[0], (int(x.split(',', 2)[1]) if len(x.split(',', 2))>1 else -1)], c.split('\n')))
            cdata = list(filter(lambda x: x[1] >= 0, cdata))
            cdata.sort(key=lambda x: x[1])
            self.items += [{'name': i[0], 'time': i[1], 'val': 1, 'row': 1} for i in cdata]
            del self.items[-1]['val']
            self.items += [{'name': '', 'time': ''}]
            self.items += [{'name': '', 'time': ''}]
            print('[CDATA]: ')
            # print('[CDATA]: ', cdata)
            for i in range(len(cdata)-1):
                self.pairs.append([cdata[i][0], cdata[i+1][0]])
                # print(len(cdata)-2-i)
                self.history.append(['Add new pair', self.pairs[-1].copy(), remove_duplicates(self.pairs.copy()), self.dual.copy(), copy.deepcopy(self.map), 
                    self.pairs[-1].copy(), 2])
                    # self.gen_csv_img(len(cdata)-i)])
                self.history[-1].append(self.gen_img_by_links_list())

                self.find_duals()

            # self.history.append(['Add new pair', self.pairs[-1].copy(), remove_duplicates(self.pairs.copy()), [], {}, 
            #     len(remove_duplicates(self.pairs))-1, 2, 
            #     self.gen_csv_img()])
        
        # print('[PAIRS]: ', self.pairs)
        # print('[DUALS]: ', self.dual)
        
        
#         print(self.dual)
#         print(self.pairs)
        self.pcpy = self.pairs.copy()
        self.dcpy = self.dual.copy()
        for ind, i in enumerate(self.pairs):
            self.add_only_first(i[0], ind)
        for ind, i in enumerate(self.dual):
            for j in i:
                self.add_only_first(j, len(self.pairs)+ind)

        for ind, i in enumerate(self.pairs):
            self.map.setdefault(i[0], {})[i[1]]=self.map.setdefault(i[0], {}).get(i[1],0)
            if self.map[i[0]][i[1]] == 0:
                self.history.append(['Add new operation', [i[0], i[1]], self.pcpy, self.dcpy, 
                    copy.deepcopy(self.map), [i[0], i[1]], 10])
                self.history[-1].append(self.gen_img_by_links_list())
            self.map.setdefault(i[0], {})[i[1]]+=1
        for ind, i in enumerate(self.pairs):
            self.add_only_last(i[1], ind)
        for ind, i in enumerate(self.dual):
            for j in i:
                self.add_only_last(j, len(self.pairs)+ind)
        self.history.append(['Final', [], self.pcpy, self.dcpy, 
            copy.deepcopy(self.map), -1, -1])
        self.new_scheme_img = self.gen_csv_img()
        self.history[-1].append(self.new_scheme_img)
        
    def get_scheme(self):
        return copy.deepcopy(self.map)
    
    def get_history(self):
        return copy.deepcopy(self.history)

PSEUDOCODE =           [{'text': 'Цикл по группам:', 'help':''},
                        {'text': '>Цикл по событиям:', 'help':'Для начала необходимо создать направленные связи (A -> B and not B -> A)'},
                        {'text': '>>Создать направленную связь', 'help':'Создание направленной связи'},
                        {'text': 'Цикл по связям:', 'help':'После построения направленных связей необходимо проверить их на наличие параллельных связей'},
                        {'text': '>Есть ли параллельная связь?', 'help':''},
                        {'text': '>>Создать параллельную связь', 'help':'Создание параллельной связи'},
                        {'text': 'Цикл по связям:', 'help':'Начало отображения модели'},
                        {'text': '>Нет ли предшественника?', 'help':'Проверяем, нет ли предшественника у выделенной жёлтым вершины'},
                        {'text': '>>Построить связь начало -> первый элемент', 'help':'Первыми отображаются переходы, у которых нет предшественника. Такие переходы соединяются со стартовой позицией'},
                        {'text': 'Цикл по направленным связям:', 'help':'Далее отображаются все направленные связи'},
                        {'text': '>Построить связь первый элемент -> второй элемент', 'help':''},
                        {'text': 'Цикл по связям:', 'help':'Последним шагом является соединение переходов, у которых нет потомка, с конечной позицией.'},
                        {'text': '>Нет ли потомка?', 'help':'Проверяем, нет ли потомка у выделенной жёлтым вершины'},
                        {'text': '>>Построить связь второй элемент -> конец', 'help':''},
                        ]



def graphviz_visualization(net, image_format="png", initial_marking=None, final_marking=None, decorations=None,
                           debug=False, set_rankdir=None, font_size="12"):
    if initial_marking is None:
        initial_marking = Marking()
    if final_marking is None:
        final_marking = Marking()
    if decorations is None:
        decorations = {}

    font_size = str(font_size)

    filename = tempfile.NamedTemporaryFile(suffix='.gv')
    viz = Digraph(net.name, filename=filename.name, engine='dot', graph_attr={'bgcolor': 'transparent'})
    if set_rankdir:
        viz.graph_attr['rankdir'] = set_rankdir
    else:
        viz.graph_attr['rankdir'] = 'LR'

    # transitions
    viz.attr('node', shape='box')
    for t in net.transitions:
        if t.label is not None:
            if t in decorations and "label" in decorations[t] and "color" in decorations[t]:
                viz.node(str(id(t)), decorations[t]["label"], style='filled', fillcolor=decorations[t]["color"],
                         border='1', fontsize=font_size)
            else:
                viz.node(str(id(t)), str(t.label), style='filled', fillcolor='aqua',
                         border='1', fontsize=font_size)
        else:
            if debug:
                viz.node(str(id(t)), str(t.name), fontsize=font_size)
            elif t in decorations and "color" in decorations[t] and "label" in decorations[t]:
                viz.node(str(id(t)), decorations[t]["label"], style='filled', fillcolor=decorations[t]["color"],
                         fontsize=font_size)
            else:
                viz.node(str(id(t)), "", style='filled', fillcolor="black", fontsize=font_size)

    # places
    # add places, in order by their (unique) name, to avoid undeterminism in the visualization
    places_sort_list_im = sorted([x for x in list(net.places) if x in initial_marking], key=lambda x: x.name)
    places_sort_list_fm = sorted([x for x in list(net.places) if x in final_marking and not x in initial_marking],
                                 key=lambda x: x.name)
    places_sort_list_not_im_fm = sorted(
        [x for x in list(net.places) if x not in initial_marking and x not in final_marking], key=lambda x: x.name)
    # making the addition happen in this order:
    # - first, the places belonging to the initial marking
    # - after, the places not belonging neither to the initial marking and the final marking
    # - at last, the places belonging to the final marking (but not to the initial marking)
    # in this way, is more probable that the initial marking is on the left and the final on the right
    places_sort_list = places_sort_list_im + places_sort_list_not_im_fm + places_sort_list_fm

    for p in places_sort_list:
        if p in initial_marking:
            viz.node(str(id(p)), 'Start', style='filled', fillcolor="green", fontsize=font_size,
                     shape='circle', fixedsize='true', width='0.75')
        elif p in final_marking:
            viz.node(str(id(p)), 'End', style='filled', fillcolor="orange", fontsize=font_size, shape='circle',
                     fixedsize='true', width='0.75')
        else:
            if debug:
                viz.node(str(id(p)), str(p.name), fontsize=font_size, shape="ellipse")
            else:
                if p in decorations and "color" in decorations[p] and "label" in decorations[p]:
                    viz.node(str(id(p)), decorations[p]["label"], style='filled', fillcolor=decorations[p]["color"],
                             fontsize=font_size, shape="ellipse")
                else:
                    viz.node(str(id(p)), "", shape='circle', fixedsize='true', width='0.75')

    # add arcs, in order by their source and target objects names, to avoid undeterminism in the visualization
    arcs_sort_list = sorted(list(net.arcs), key=lambda x: (x.source.name, x.target.name))
    for a in arcs_sort_list:
        if a in decorations and "label" in decorations[a] and "penwidth" in decorations[a]:
            viz.edge(str(id(a.source)), str(id(a.target)), label=decorations[a]["label"],
                     penwidth=decorations[a]["penwidth"], fontsize=font_size)
        elif a in decorations and "color" in decorations[a]:
            viz.edge(str(id(a.source)), str(id(a.target)), color=decorations[a]["color"], fontsize=font_size)
        else:
            viz.edge(str(id(a.source)), str(id(a.target)), fontsize=font_size)
    viz.attr(overlap='false')

    viz.format = image_format

    return viz


'''

Tel_call, 1
Document_writing, 10
Doc_sending, 20

Message receiving, 50
Document_sending, 55

Message receiving, 50
Doc_sending, 55

'''