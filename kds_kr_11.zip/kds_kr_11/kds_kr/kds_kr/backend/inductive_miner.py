import copy
from kds_kr.backend import alpha_miner
from pm4py.algo.discovery.inductive import algorithm as inductive_miner_algo

class inductive_miner(alpha_miner.alpha_miner):
    
    class cluster(list):
        _cl_num = '_c0'
        
        def __hash__(self):
            return int(self._cl_num[2:])
        
        def hash(self):
            return self.__hash__()
        
        def __str__(self):
            return self._cl_num + ': ' + super().__str__()
        
        pass
    
    def merge_to_cluster(self, i, j, ind=-1, p=14):
        self.clusters[j._cl_num].append(i)
        cmap = self.map.copy()
        for l in list(cmap.keys()):
            if l == i:
                for m in list(cmap[l].keys()):
                    cmap[j._cl_num][m] = cmap.setdefault(j._cl_num, {}).get(m, 0)+copy.deepcopy(cmap[l][m])
                del cmap[l]
            else:
                for m in list(cmap[l].keys()):
                    if m == i:
                        cmap[l][j._cl_num] = cmap[l].get(j._cl_num,0)+copy.deepcopy(cmap[l][m])
                        del cmap[l][m]
                        # self.history.append(['Merge to cluster', i, self.pairs, self.dual, copy.deepcopy(cmap)])
        cmap[j._cl_num][j._cl_num] = 0
        del cmap[j._cl_num][j._cl_num]
        self.map = cmap
        self.history.append(['Merge to cluster', i, self.pairs, self.dual, copy.deepcopy(self.map), ind, p])
        self.history[-1].append(self.gen_img_by_links_list())

    
    def gen_clusters(self):
        self.clusters = {}
        for ind, i in enumerate(self.map):
            s = sum(self.map[i].values())
            if s < self.grad:
                isnew = 1
                for k in self.map:
                    print(i, k)
                    if i in self.map[k].keys():
                        kkeys = list(self.map[k].keys())
                        print(i, k, kkeys)
                        kkeys.sort(key=lambda x: sum(self.map[x].values()), reverse=True)
                        print(i, k, kkeys)
                        for j in kkeys:
                            print(j)
                            if j == i:
                                continue
                            if str(j)[:2] == '_c':
                                self.merge_to_cluster(i, self.clusters[j], ind, 16)
                                isnew = 0
                                break
                            if not isnew:
                                break
                    if not isnew:
                        break
                if isnew:
                    cl = fuzzy_miner.cluster([])
                    cl._cl_num = '_c'+str(len(self.clusters))
                    self.clusters[cl._cl_num] = cl
                    print('CL: ', self.clusters)
                    self.merge_to_cluster(i, cl, 16)
                    
    def simplify_clusters(self):
        ischanged = 0
        for ind, i in enumerate(list(self.map.keys())):
            if self.map.get(i) is None or str(i)[:2] != '_c':
                continue
            for j in list(self.map[i].keys()):
                if self.map.get(j) is None or str(j)[:2] != '_c':
                    continue
                s = sum(self.map[i].values()) + sum(self.map[j].values())
                if s < self.grad:
                    self.clusters[i] += list(self.clusters[j])
                    self.merge_to_cluster(j, self.clusters[i], -1, 19)

    def __init__(self, data, grad = 0.1):
        super().__init__(data)
        self.grad=grad*len(data)

        self.history = self.history[:-1]
        print('CLUSTERS')
        
        self.history.append(['Final', [], self.pcpy, self.dcpy, 
            copy.deepcopy(self.map), -1, 14])
        self.new_scheme_img = self.gen_csv_img(algo=inductive_miner_algo)
        self.history[-1].append(self.new_scheme_img)





    
        
    def get_scheme(self):
        return copy.deepcopy(self.map)
    
    def get_history(self):
        return copy.deepcopy(self.history)

PSEUDOCODE = alpha_miner.PSEUDOCODE + [
                        {'text': 'Добавить фиктивные вершины в ветвления и параллельные процессы (чёрные)', 'help':'''производится ЦИКЛ ПО РАЗДЕЛЕНИЯМ по параллельным позициям:
производится проверка МОЖНО ЛИ ИЗ ЛЕВОЙ ЧАСТИ ПОПАСТЬ В ОБХОД В ПРАВУЮ ЧАСТЬ ЕСЛИ ДА – добавляется отображение фиктивной вершины
Далее производится обратная проверка: МОЖНО ЛИ ИЗ ЛЕВОЙ ЧАСТИ ПОПАСТЬ В ОБХОД В ПРАВУЮ ЧАСТЬ ЕСЛИ ДА – добавляется отображение фиктивной вершины'''},
                        ]


'''


Tel_call, 1
Document_writing, 10
Doc_sending, 20

Message receiving, 50
Document_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

Message receiving, 50
Doc_sending, 55

'''