from django.http import HttpResponse

def linc_check_funk(request):
	return HttpResponse('test')