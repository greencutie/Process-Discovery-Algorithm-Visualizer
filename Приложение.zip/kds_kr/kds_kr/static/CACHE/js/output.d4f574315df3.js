function test_plot(){var g=new Dracula.Graph();g.addEdge("strawberry","cherry");g.addEdge("strawberry","apple");g.addEdge("strawberry","tomato");g.addEdge("tomato","apple");g.addEdge("tomato","kiwi");g.addEdge("cherry","apple");g.addEdge("cherry","kiwi",{directed:true});var layouter=new Dracula.Layout.Spring(g);layouter.layout();var renderer=new Dracula.Renderer.Raphael('#plot',g,400,300);renderer.draw();}
function plot_by_pairs(idx){var data=JSON.parse(document.getElementById('data').textContent.replace(/\'/g,"\""))
console.log(data)
var g=new Dracula.Graph();for(const[first,value]of Object.entries(data[idx][4])){console.log(first,value);for(const[second,val]of Object.entries(value)){g.addEdge(first,second,{directed:true});}}
var layouter=new Dracula.Layout.Spring(g);layouter.layout();document.getElementById('plot').textContent=""
var renderer=new Dracula.Renderer.Raphael('#plot',g,400,300);renderer.draw();}