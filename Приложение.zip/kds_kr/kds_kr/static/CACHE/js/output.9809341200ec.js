var current_step=-1;var json_data;var len=100;function hasClass(el,className)
{if(el.classList)
return el.classList.contains(className);return!!el.className.match(new RegExp('(\\s|^)'+className+'(\\s|$)'));}
function addClass(el,className)
{if(el.classList)
el.classList.add(className)
else if(!hasClass(el,className))
el.className+=" "+className;}
function removeClass(el,className)
{if(el.classList)
el.classList.remove(className)
else if(hasClass(el,className))
{var reg=new RegExp('(\\s|^)'+className+'(\\s|$)');el.className=el.className.replace(reg,' ');}}
function parse_links(n,data){var dir_links=data[n][2]
var parallel_links=data[n][3]
var select_ind_i=data[n][5][0]
var select_ind_j=data[n][5][1]
var select_ind_t=data[n][5]
var clusters=data[n][8]
var elems=document.getElementsByClassName('source_row')
var s=`
					<tr style="position: sticky; top: 0;">
                        <th width="45%">Первый</th>
                        <th width="10%">связь</th>
                        <th width="45%">Второй</th>
                    </tr>`
for(var i=0;i<dir_links.length;i++){var cls=''
if(dir_links[i][0]==select_ind_i&&dir_links[i][1]==select_ind_j||'_start'==select_ind_i&&dir_links[i][0]==select_ind_j||dir_links[i][1]==select_ind_i&&'_end'==select_ind_j){cls='selected'}
if('_start'==select_ind_i&&dir_links[i][1]==select_ind_j||dir_links[i][0]==select_ind_i&&'_end'==select_ind_j){cls='selected_red'}
s+=`
					<tr class="directed_row ${cls}">
                        <td>${dir_links[i][0]}</td>
                        <td style="text-align: center;">-></td>
                        <td>${dir_links[i][1]}</td>
                    </tr>
		`}
for(var i=0;i<parallel_links.length;i++){var cls=''
if(parallel_links[i][0]==select_ind_i&&parallel_links[i][1]==select_ind_j||'_start'==select_ind_i&&parallel_links[i][0]==select_ind_j||parallel_links[i][1]==select_ind_i&&'_end'==select_ind_j){cls='selected'}
if('_start'==select_ind_i&&parallel_links[i][1]==select_ind_j||parallel_links[i][0]==select_ind_i&&'_end'==select_ind_j){cls='selected_red'}
s+=`
					<tr class="parralel_row ${cls}">
                        <td>${parallel_links[i][0]}</td>
                        <td style="text-align: center;">||</td>
                        <td>${parallel_links[i][1]}</td>
                    </tr>
		`}
if(clusters){s+=`
					<tr class="parralel_row">
	                    <td style="text-align: center;" colspan="3">Clusters</td>
	                </tr>
		`
for(const[c_name,items_list]of Object.entries(clusters)){for(var i=0;i<items_list.length;i++){var cls=''
if(c_name==select_ind_i&&items_list[i]==select_ind_j){cls='selected'}
if(c_name==select_ind_j){cls='selected_red'}
s+=`
							<tr class="parralel_row ${cls}">
		                        <td>${c_name}</td>
		                        <td style="text-align: center;"><-</td>
		                        <td>${items_list[i]}</td>
		                    </tr>
				`}}}
document.getElementById('link_table').innerHTML=s}
function test_plot(){var g=new Dracula.Graph();g.addEdge("strawberry","cherry");g.addEdge("strawberry","apple");g.addEdge("strawberry","tomato");g.addEdge("tomato","apple");g.addEdge("tomato","kiwi");g.addEdge("cherry","apple");g.addEdge("cherry","kiwi",{directed:true});var layouter=new Dracula.Layout.Spring(g);layouter.layout();var box=document.getElementById('plot')
var renderer=new Dracula.Renderer.Raphael('#plot',g,box.offsetWidth,box.offsetHeight);renderer.draw();}
function plot_by_pairs(idx){if(json_data==undefined){json_data=JSON.parse(document.getElementById('data').textContent)}
len=json_data.length
parse_links(idx,json_data)
var g=new Dracula.Graph();for(const[first,value]of Object.entries(json_data[idx][4])){for(const[second,val]of Object.entries(value)){var value_label=parseInt(val)
if(value_label<=1){value_label=''}
if(parseInt(val)==0)
g.addEdge(first,second,{directed:true,label:value_label,stroke:'#f00',fill:'#f00'});else
g.addEdge(first,second,{directed:true,label:value_label,stroke:'#bfa',fill:'#56f'});}}
var layouter=new Dracula.Layout.Spring(g);layouter.layout();document.getElementById('plot').textContent=""
var box=document.getElementById('plot')
var renderer=new Dracula.Renderer.Raphael('#plot',g,box.offsetWidth,box.offsetHeight);renderer.draw();document.getElementById('plot2').innerHTML=json_data[idx][7]}
function next_step(){if(json_data==undefined){json_data=JSON.parse(document.getElementById('data').textContent)}
if(current_step<json_data.length-1){var elems=document.getElementsByClassName('source_row')
if(elems.length>current_step&&current_step>=0){removeClass(elems[current_step],'selected')}
if(current_step>=0&&json_data[current_step][6]&&json_data[current_step][6]>=0)
removeClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
current_step=current_step+1;if(json_data[current_step][6]&&json_data[current_step][6]>=0)
addClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
plot_by_pairs(current_step)
if(elems.length>current_step){addClass(elems[current_step],'selected')}
document.getElementById('bar').style.width=(current_step+1)*100/len+"%";}}
function previous_step(){if(json_data==undefined){json_data=JSON.parse(document.getElementById('data').textContent)}
if(current_step>0){var elems=document.getElementsByClassName('source_row')
if(elems.length>current_step){removeClass(elems[current_step],'selected')}
if(json_data[current_step][6]&&json_data[current_step][6]>=0)
removeClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
current_step=current_step-1;if(json_data[current_step][6]&&json_data[current_step][6]>=0)
addClass(document.getElementsByClassName('pseudo_row')[json_data[current_step][6]],'selected')
plot_by_pairs(current_step)
if(elems.length>current_step){addClass(elems[current_step],'selected')}
document.getElementById('bar').style.width=(current_step+1)*100/len+"%";}}